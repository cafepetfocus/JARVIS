# JARVIS Android — prototype 0.1.0

Premier prototype natif Android en Java, sans dépendance de bibliothèque externe. Il contient une interface de discussion, un historique local, une mémoire explicite via `/remember ...`, des instructions de personnalité configurables, un endpoint compatible avec l'API Chat Completions et un export des données.

## État honnête

- Source du projet créée : oui.
- APK compilée : non, pas dans cet environnement.
- Installée ou testée sur un Samsung S23 : non.
- Connexion à un fournisseur réel : à configurer et tester.

## Sécurité importante

La clé API saisie est conservée dans les préférences privées de l'application, mais elle n'est pas stockée dans un coffre matériel dédié. Une application Android cliente ne peut pas cacher parfaitement un secret. N'utilise pas une clé donnant accès à des dépenses importantes. Pour une version distribuée, il faudra un backend qui conserve la clé côté serveur ou un mécanisme d'authentification sûr.

## Compiler depuis Android

Ce projet utilise Gradle et Android Gradle Plugin 8.7.3, compileSdk 35 et minSdk 26. Il faut un environnement Android compatible et le SDK Android correspondant. Les IDE Android sur téléphone peuvent avoir des limites de compatibilité; vérifie la documentation et la provenance avant d'installer un outil de développement. AndroidIDE officiel est archivé et n'est plus maintenu.

1. Décompresse `JARVIS-Android-Prototype.zip` dans un environnement Android de développement.
2. Ouvre le dossier `JARVIS` comme projet Gradle.
3. Autorise le téléchargement des dépendances Gradle et du SDK si demandé.
4. Lance la tâche `assembleDebug`.
5. Si la compilation réussit, l'APK de débogage sera normalement dans `app/build/outputs/apk/debug/app-debug.apk`.

Aucun `gradlew` ni wrapper JAR n'est inclus dans cette première archive. Il faudra utiliser le Gradle fourni par l'environnement de compilation ou générer un wrapper compatible.

## Configurer l'IA

Dans Réglages, renseigne l'URL complète du endpoint Chat Completions, le nom du modèle et éventuellement la clé. Les API ne sont pas toutes compatibles, même si elles ressemblent à l'API OpenAI. N'utilise que le endpoint officiel d'un fournisseur choisi et vérifie ses tarifs/limites avant de fournir une clé.

## Structure

- `app/src/main/java/com/jarvis/assistant/MainActivity.java` : interface, conversation, mémoire, réglages et appel HTTP.
- `app/src/main/AndroidManifest.xml` : déclaration Android et permission Internet.
- `app/src/main/res/values/styles.xml` : thème.
- `app/build.gradle` : configuration de l'application.

## Compilation à distance depuis le téléphone (GitHub Actions)

L'archive inclut `.github/workflows/build-apk.yml`. Une fois le dossier importé dans un dépôt GitHub, le workflow peut compiler l'APK sur une machine distante. Les workflows Actions standards sur un dépôt public sont généralement sans frais selon la documentation GitHub; vérifie les conditions du compte et du dépôt avant usage.

1. Crée un dépôt GitHub public vide depuis Chrome (ne mets jamais de clé API dans le dépôt).
2. Téléverse les fichiers du projet dans le dépôt, en conservant le dossier caché `.github` et son workflow.
3. Ouvre l'onglet **Actions** du dépôt et autorise les workflows si GitHub le demande.
4. Lance **Build JARVIS APK** via **Run workflow**, ou pousse un changement sur la branche `main`.
5. Quand le workflow est terminé avec succès, ouvre son exécution, puis télécharge l'artefact `JARVIS-debug-APK`.
6. Décompresse l'artefact sur le téléphone et ouvre l'APK. Android peut demander d'autoriser l'installation depuis cette source; n'autorise que les APK que tu as compilées et dont tu comprends la provenance.

Ce workflow n'a pas été exécuté dans cet environnement. Il faudra vérifier son résultat réel sur GitHub avant de considérer l'APK comme compilée.
